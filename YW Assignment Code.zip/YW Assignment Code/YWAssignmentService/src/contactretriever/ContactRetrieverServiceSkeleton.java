/**
 * ContactRetrieverServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.9  Built on : Nov 16, 2018 (12:05:37 GMT)
 */
package contactretriever;


/**
 *  ContactRetrieverServiceSkeleton java skeleton for the axisService
 */
public class ContactRetrieverServiceSkeleton {
    /**
     * Auto generated method signature
     *
     * @param getRequest
     * @return getResponse
     * @throws ErrorFault
     */
    public contactretriever.GetResponse retrieveContactOperation(
        contactretriever.GetRequest getRequest) throws ErrorFault {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#retrieveContactOperation");
    }

    /**
     * Auto generated method signature
     *
     * @param deleteRequest
     * @return
     * @throws ErrorFault
     */
    public void deleteContactOperation(
        contactretriever.DeleteRequest deleteRequest) throws ErrorFault {
        //TODO : fill this with the necessary business logic
    }

    /**
     * Auto generated method signature
     *
     * @param modifyRequest
     * @return
     * @throws ErrorFault
     */
    public void modifyContactOperation(
        contactretriever.ModifyRequest modifyRequest) throws ErrorFault {
        //TODO : fill this with the necessary business logic
    }

    /**
     * Auto generated method signature
     *
     * @param insertRequest
     * @return
     * @throws ErrorFault
     */
    public void insertContactOperation(
        contactretriever.InsertRequest insertRequest) throws ErrorFault {
        //TODO : fill this with the necessary business logic
    }
}
