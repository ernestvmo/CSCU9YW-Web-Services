package contactretriever;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ContactRetrieverService extends ContactRetrieverServiceSkeleton
{
	/** Path to the database location. */
	private static String path = "jdbc:mysql://localhost:3306/contactsDB";
	/** Database username. */
	private static String username = "root";
	/** Database password. */
	private static String password = "root";
	
	/**
	 * Returns a connection to the remote database.
	 * 
	 * @return The connection object created.
	 */
	private Connection connect()
	{
		String url = path;

		Connection conn = null;

		try
		{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url, username, password);
		}
		catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e)
		{
			System.out.println(e.getMessage());
		}

		return conn;
	}
	
	/**
	 * This method searches for a contact in the database with the passed phone number.
	 * 
	 * @param phoneID The phone number of the contact we want to retrieve.
	 * 
	 * @return The contact object associated with the phone number.
	 * 
	 * @throws ErrorFault
	 */
	private Contact getContact(String phoneID) throws ErrorFault
	{
		String sql = "SELECT first_name, last_name, phone, email, house_num, street, city, postcode "
				+ "FROM contacts WHERE phone = '" + phoneID + "';";

		Contact c = new Contact();
		
		try (Connection conn = connect();
				Statement statement = conn.createStatement();
				ResultSet rs = statement.executeQuery(sql))
		{
			while (rs.next())
			{
				Address a = new Address();
				
				a.setNumber(rs.getString("house_num"));
				a.setStreet(rs.getString("street"));
				a.setCity(rs.getString("city"));
				a.setPostcode(rs.getString("postcode"));
				
				c = new Contact();
				
				c.setFirstName(rs.getString("first_name"));
				c.setLastName(rs.getString("last_name"));
				c.setPhone(rs.getString("phone"));
				c.setEmail(rs.getString("email"));
				c.setAddress(a);
				
				conn.close();
				
				return c;
			}				
			
			conn.close();
		}
		catch (SQLException e)
		{
			throw new ErrorFault("Error getting the Contact from the database.");
		}
		
		return null;
	}
	
	/**
	 * This method receives a Get Request, which it uses to find and a Contact in the database.<br>
	 * The method then returns this contact in the form of a Get Response.
	 */
	public GetResponse retrieveContactOperation(GetRequest retriever) throws ErrorFault
	{
		String phoneID = retriever.getGetRequest();
		
		GetResponse response = new GetResponse();
		
		Contact c = getContact(phoneID);
		
		if (c == null)
			throw new ErrorFault("No contact found with the given phone number.");
			
		response.setGetResponse(c);
		
		return response;
	}
	
	/**
	 * This method receives a Insert Request, which it uses to insert a Contact in the database.
	 */
	public void insertContactOperation(InsertRequest request) throws ErrorFault 
	{
		Contact c = request.getInsertRequest();
		
		if (getContact(c.getPhone()) != null)
			throw new ErrorFault("A contact already exists with this phone number!");
		
		String sql = "INSERT INTO contacts(first_name, last_name, phone, email, house_num, street, city, postcode) VALUES(?,?,?,?,?,?,?,?);";

		try (Connection conn = connect();
				PreparedStatement statement = conn.prepareStatement(sql))
		{
			if (getContact(c.getPhone()) != null)
				throw new ErrorFault("The database already contains a contain with the given phone number!");
			else
			{
				Address a = c.getAddress();

				statement.setString(1, c.getFirstName());
				statement.setString(2, c.getLastName());
				statement.setString(3, c.getPhone());
				statement.setString(4, c.getEmail());
				statement.setString(5, a.getNumber());
				statement.setString(6, a.getStreet());
				statement.setString(7, a.getCity());
				statement.setString(8, a.getPostcode());
				statement.executeUpdate();
				
				conn.close();
			}
		}
		catch (SQLException e)
		{
//			System.out.println(e.getMessage());
			throw new ErrorFault("An error occured trying to insert the new contact to the database!");
		}
	}
	
	/**	 
	 * This method receives a Delete Request, which it uses to delete a Contact in the database.
	 */
	public void deleteContactOperation(DeleteRequest request) throws ErrorFault
	{
		String phoneID = request.getDeleteRequest();

		String sql = "DELETE FROM contacts WHERE phone = ?;";
		
		if (getContact(phoneID) == null)
			throw new ErrorFault("No contact exists with the given phone number!");
		
		try (Connection conn = connect();
				PreparedStatement statement = conn.prepareStatement(sql))
		{
			statement.setString(1, phoneID);
			statement.executeUpdate();
			conn.close();
		}
		catch (SQLException e)
		{
//			System.out.println(e.getMessage());
			throw new ErrorFault("An error occured trying to delete the contact from the database!");
		}
	}
	
	/**
	 * This method receives a Modification Request, which it uses to update a Contact in the database.
	 */
	public void modifyContactOperation(ModifyRequest request) throws ErrorFault
	{
		Contact c = request.getModifyRequest();
		
		String sql = "UPDATE contacts SET first_name = ?, "
				+ "last_name = ?, "
				+ "email = ?, "
				+ "house_num = ?, "
				+ "street = ?, "
				+ "city = ?, "
				+ "postcode = ? "
				+ "WHERE phone = ?";
		

		if (getContact(c.getPhone()) == null)
			throw new ErrorFault("No contact exists with the given phone number!");
		
		try (Connection conn = connect();
				PreparedStatement statement = conn.prepareStatement(sql))
		{
			Address a = c.getAddress();
			
			statement.setString(1, c.getFirstName());
			statement.setString(2, c.getLastName());
			statement.setString(3, c.getEmail());
			statement.setString(4, a.getNumber());
			statement.setString(5, a.getStreet());
			statement.setString(6, a.getCity());
			statement.setString(7, a.getPostcode());
			statement.setString(8, c.getPhone());
			statement.executeUpdate();
			conn.close();
		}
		catch (SQLException e)
		{
//			System.out.println(e.getMessage());
			throw new ErrorFault("An error occured trying to modify the contact from the database!");
		}
	}
}
