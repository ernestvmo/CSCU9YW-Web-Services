package appmanager;


import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JTextField;
import javax.swing.UIManager;

import java.awt.Dimension;
import javax.swing.JButton;
import java.awt.Font;
import contactretriever.ContactRetrieverServiceStub;
import contactretriever.ErrorFault;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.awt.event.ActionEvent;

/**
 * @author 2634056
 */
public class UI implements ActionListener
{
	private JFrame frameContactManager;
	private JTextField txtSearchField;
	private JButton btnInsertContact;
	private JButton btnModifyContact;
	private JButton btnDeleteContact;
	private JButton btnFindContact;
	
	private JButton btnClear;
	private JPanel panelContactDisplay;
	private JLabel lblNewLabel;
	private JLabel lblFirstName;
	private JLabel lblLastName;
	private JLabel lblPhone;
	private JLabel lblEmail;
	private JLabel lblAddress;
	private JLabel lblHouseNumber;
	private JLabel lblStreet;
	private JLabel lblCity;
	private JLabel lblPostcode;

	private ContactManager cm;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			UI window = new UI();
			window.frameContactManager.setVisible(true);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Constructor to create the application.
	 */
	public UI()
	{
		initialize();
		cm = new ContactManager();
	}

	/**
	 * Initialise the contents of the frame.
	 */
	private void initialize()
	{
		frameContactManager = new JFrame();
		frameContactManager.setResizable(false);
		frameContactManager.setTitle("Contact Manager");
		frameContactManager.setBounds(100, 100, 776, 550);
		frameContactManager.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frameContactManager.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panelSearch = new JPanel();
		panelSearch.setMinimumSize(new Dimension(10, 250));
		panelSearch.setPreferredSize(new Dimension(10, 250));
		panel.add(panelSearch, BorderLayout.NORTH);
		GridBagLayout gbl_panelSearch = new GridBagLayout();
		gbl_panelSearch.columnWidths = new int[]{0, 150, 150, 150, 150, 0, 0};
		gbl_panelSearch.rowHeights = new int[]{0, 35, 30, 35, 0, 0};
		gbl_panelSearch.columnWeights = new double[]{1.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panelSearch.rowWeights = new double[]{1.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		panelSearch.setLayout(gbl_panelSearch);
		
		JLabel lblFieldLabel = new JLabel("Phone Number:");
		lblFieldLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		GridBagConstraints gbc_lblFieldLabel = new GridBagConstraints();
		gbc_lblFieldLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblFieldLabel.anchor = GridBagConstraints.EAST;
		gbc_lblFieldLabel.fill = GridBagConstraints.VERTICAL;
		gbc_lblFieldLabel.gridx = 1;
		gbc_lblFieldLabel.gridy = 1;
		panelSearch.add(lblFieldLabel, gbc_lblFieldLabel);
		
		txtSearchField = new JTextField();
		GridBagConstraints gbc_txtSearchField = new GridBagConstraints();
		gbc_txtSearchField.gridwidth = 2;
		gbc_txtSearchField.insets = new Insets(0, 0, 5, 5);
		gbc_txtSearchField.fill = GridBagConstraints.BOTH;
		gbc_txtSearchField.gridx = 2;
		gbc_txtSearchField.gridy = 1;
		panelSearch.add(txtSearchField, gbc_txtSearchField);
		txtSearchField.setColumns(10);
		
		btnFindContact = new JButton("Find Contact");
		btnFindContact.addActionListener(this);
		GridBagConstraints gbc_btnFindContact = new GridBagConstraints();
		gbc_btnFindContact.fill = GridBagConstraints.VERTICAL;
		gbc_btnFindContact.insets = new Insets(0, 0, 5, 5);
		gbc_btnFindContact.gridx = 4;
		gbc_btnFindContact.gridy = 1;
		panelSearch.add(btnFindContact, gbc_btnFindContact);
		
		btnInsertContact = new JButton("Insert");
		btnInsertContact.setOpaque(true);
		btnInsertContact.addActionListener(this);
		btnInsertContact.setPreferredSize(new Dimension(80, 23));
		GridBagConstraints gbc_btnInsertContact = new GridBagConstraints();
		gbc_btnInsertContact.fill = GridBagConstraints.VERTICAL;
		gbc_btnInsertContact.insets = new Insets(0, 0, 5, 5);
		gbc_btnInsertContact.gridx = 1;
		gbc_btnInsertContact.gridy = 3;
		panelSearch.add(btnInsertContact, gbc_btnInsertContact);
		
		btnModifyContact = new JButton("Modify");
		btnModifyContact.addActionListener(this);
		btnModifyContact.setEnabled(false);
		btnModifyContact.setPreferredSize(new Dimension(80, 23));
		GridBagConstraints gbc_btnModifyContact = new GridBagConstraints();
		gbc_btnModifyContact.fill = GridBagConstraints.VERTICAL;
		gbc_btnModifyContact.insets = new Insets(0, 0, 5, 5);
		gbc_btnModifyContact.gridx = 2;
		gbc_btnModifyContact.gridy = 3;
		panelSearch.add(btnModifyContact, gbc_btnModifyContact);
		
		btnDeleteContact = new JButton("Delete");
		btnDeleteContact.addActionListener(this);
		btnDeleteContact.setEnabled(false);
		btnDeleteContact.setPreferredSize(new Dimension(80, 23));
		GridBagConstraints gbc_btnDeleteContact = new GridBagConstraints();
		gbc_btnDeleteContact.fill = GridBagConstraints.VERTICAL;
		gbc_btnDeleteContact.insets = new Insets(0, 0, 5, 5);
		gbc_btnDeleteContact.gridx = 3;
		gbc_btnDeleteContact.gridy = 3;
		panelSearch.add(btnDeleteContact, gbc_btnDeleteContact);
		
		btnClear = new JButton("Clear");
		btnClear.addActionListener(this);
		btnClear.setPreferredSize(new Dimension(80, 35));
		GridBagConstraints gbc_btnClear = new GridBagConstraints();
		gbc_btnClear.fill = GridBagConstraints.VERTICAL;
		gbc_btnClear.insets = new Insets(0, 0, 5, 5);
		gbc_btnClear.gridx = 4;
		gbc_btnClear.gridy = 3;
		panelSearch.add(btnClear, gbc_btnClear);
		
		panelContactDisplay = new JPanel();
		panel.add(panelContactDisplay, BorderLayout.CENTER);
		GridBagLayout gbl_panelContactDisplay = new GridBagLayout();
		gbl_panelContactDisplay.columnWidths = new int[]{0, 100, 30, 200, 100, 0, 100, 0, 0};
		gbl_panelContactDisplay.rowHeights = new int[]{0, 30, 30, 30, 30, 30, 0, 0};
		gbl_panelContactDisplay.columnWeights = new double[]{1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panelContactDisplay.rowWeights = new double[]{1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		panelContactDisplay.setLayout(gbl_panelContactDisplay);
		
		lblNewLabel = new JLabel("Contact");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.fill = GridBagConstraints.VERTICAL;
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 1;
		panelContactDisplay.add(lblNewLabel, gbc_lblNewLabel);
		
		lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Tahoma", Font.BOLD, 16));
		GridBagConstraints gbc_lblAddress = new GridBagConstraints();
		gbc_lblAddress.anchor = GridBagConstraints.EAST;
		gbc_lblAddress.insets = new Insets(0, 0, 5, 5);
		gbc_lblAddress.gridx = 4;
		gbc_lblAddress.gridy = 1;
		panelContactDisplay.add(lblAddress, gbc_lblAddress);
		
		JLabel lblFirstNameLabel = new JLabel("First Name :");
		lblFirstNameLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		GridBagConstraints gbc_lblFirstNameLabel = new GridBagConstraints();
		gbc_lblFirstNameLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblFirstNameLabel.anchor = GridBagConstraints.EAST;
		gbc_lblFirstNameLabel.gridx = 1;
		gbc_lblFirstNameLabel.gridy = 2;
		panelContactDisplay.add(lblFirstNameLabel, gbc_lblFirstNameLabel);
		
		lblFirstName = new JLabel("First Name");
		lblFirstName.setFont(new Font("Consolas", Font.PLAIN, 13));
		GridBagConstraints gbc_lblFirstName = new GridBagConstraints();
		gbc_lblFirstName.fill = GridBagConstraints.VERTICAL;
		gbc_lblFirstName.anchor = GridBagConstraints.WEST;
		gbc_lblFirstName.insets = new Insets(0, 0, 5, 5);
		gbc_lblFirstName.gridx = 3;
		gbc_lblFirstName.gridy = 2;
		panelContactDisplay.add(lblFirstName, gbc_lblFirstName);
		
		JLabel lblHouseNumberLabel = new JLabel("Nº :");
		lblHouseNumberLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		GridBagConstraints gbc_lblHouseNumberLabel = new GridBagConstraints();
		gbc_lblHouseNumberLabel.anchor = GridBagConstraints.EAST;
		gbc_lblHouseNumberLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblHouseNumberLabel.gridx = 4;
		gbc_lblHouseNumberLabel.gridy = 2;
		panelContactDisplay.add(lblHouseNumberLabel, gbc_lblHouseNumberLabel);
		
		lblHouseNumber = new JLabel("House Number");
		lblHouseNumber.setFont(new Font("Consolas", Font.PLAIN, 13));
		GridBagConstraints gbc_lblHouseNumber = new GridBagConstraints();
		gbc_lblHouseNumber.anchor = GridBagConstraints.WEST;
		gbc_lblHouseNumber.insets = new Insets(0, 0, 5, 5);
		gbc_lblHouseNumber.gridx = 6;
		gbc_lblHouseNumber.gridy = 2;
		panelContactDisplay.add(lblHouseNumber, gbc_lblHouseNumber);
		
		JLabel lblLastNameLabel = new JLabel("Last Name :");
		lblLastNameLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		GridBagConstraints gbc_lblLastNameLabel = new GridBagConstraints();
		gbc_lblLastNameLabel.anchor = GridBagConstraints.EAST;
		gbc_lblLastNameLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblLastNameLabel.gridx = 1;
		gbc_lblLastNameLabel.gridy = 3;
		panelContactDisplay.add(lblLastNameLabel, gbc_lblLastNameLabel);
		
		lblLastName = new JLabel("Last Name");
		lblLastName.setFont(new Font("Consolas", Font.PLAIN, 13));
		GridBagConstraints gbc_lblLastName = new GridBagConstraints();
		gbc_lblLastName.fill = GridBagConstraints.VERTICAL;
		gbc_lblLastName.anchor = GridBagConstraints.WEST;
		gbc_lblLastName.insets = new Insets(0, 0, 5, 5);
		gbc_lblLastName.gridx = 3;
		gbc_lblLastName.gridy = 3;
		panelContactDisplay.add(lblLastName, gbc_lblLastName);
		
		JLabel lblStreetLabel = new JLabel("Street :");
		lblStreetLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		GridBagConstraints gbc_lblStreetLabel = new GridBagConstraints();
		gbc_lblStreetLabel.anchor = GridBagConstraints.EAST;
		gbc_lblStreetLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblStreetLabel.gridx = 4;
		gbc_lblStreetLabel.gridy = 3;
		panelContactDisplay.add(lblStreetLabel, gbc_lblStreetLabel);
		
		lblStreet = new JLabel("Street");
		lblStreet.setFont(new Font("Consolas", Font.PLAIN, 13));
		GridBagConstraints gbc_lblStreet = new GridBagConstraints();
		gbc_lblStreet.anchor = GridBagConstraints.WEST;
		gbc_lblStreet.insets = new Insets(0, 0, 5, 5);
		gbc_lblStreet.gridx = 6;
		gbc_lblStreet.gridy = 3;
		panelContactDisplay.add(lblStreet, gbc_lblStreet);
		
		JLabel lblPhoneLabel = new JLabel("Phone :");
		lblPhoneLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		GridBagConstraints gbc_lblPhoneLabel = new GridBagConstraints();
		gbc_lblPhoneLabel.anchor = GridBagConstraints.EAST;
		gbc_lblPhoneLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblPhoneLabel.gridx = 1;
		gbc_lblPhoneLabel.gridy = 4;
		panelContactDisplay.add(lblPhoneLabel, gbc_lblPhoneLabel);
		
		lblPhone = new JLabel("Phone");
		lblPhone.setFont(new Font("Consolas", Font.PLAIN, 13));
		GridBagConstraints gbc_lblPhone = new GridBagConstraints();
		gbc_lblPhone.fill = GridBagConstraints.VERTICAL;
		gbc_lblPhone.anchor = GridBagConstraints.WEST;
		gbc_lblPhone.insets = new Insets(0, 0, 5, 5);
		gbc_lblPhone.gridx = 3;
		gbc_lblPhone.gridy = 4;
		panelContactDisplay.add(lblPhone, gbc_lblPhone);
		
		JLabel lblCityLabel = new JLabel("City :");
		lblCityLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		GridBagConstraints gbc_lblCityLabel = new GridBagConstraints();
		gbc_lblCityLabel.anchor = GridBagConstraints.EAST;
		gbc_lblCityLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblCityLabel.gridx = 4;
		gbc_lblCityLabel.gridy = 4;
		panelContactDisplay.add(lblCityLabel, gbc_lblCityLabel);
		
		lblCity = new JLabel("City ");
		lblCity.setFont(new Font("Consolas", Font.PLAIN, 13));
		GridBagConstraints gbc_lblCity = new GridBagConstraints();
		gbc_lblCity.anchor = GridBagConstraints.WEST;
		gbc_lblCity.insets = new Insets(0, 0, 5, 5);
		gbc_lblCity.gridx = 6;
		gbc_lblCity.gridy = 4;
		panelContactDisplay.add(lblCity, gbc_lblCity);
		
		JLabel lblEmailLabel = new JLabel("Email :");
		lblEmailLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		GridBagConstraints gbc_lblEmailLabel = new GridBagConstraints();
		gbc_lblEmailLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblEmailLabel.anchor = GridBagConstraints.EAST;
		gbc_lblEmailLabel.gridx = 1;
		gbc_lblEmailLabel.gridy = 5;
		panelContactDisplay.add(lblEmailLabel, gbc_lblEmailLabel);
		
		lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Consolas", Font.PLAIN, 13));
		GridBagConstraints gbc_lblEmail = new GridBagConstraints();
		gbc_lblEmail.fill = GridBagConstraints.VERTICAL;
		gbc_lblEmail.insets = new Insets(0, 0, 5, 5);
		gbc_lblEmail.anchor = GridBagConstraints.WEST;
		gbc_lblEmail.gridx = 3;
		gbc_lblEmail.gridy = 5;
		panelContactDisplay.add(lblEmail, gbc_lblEmail);
		
		JLabel lblPostcodeLabel = new JLabel("Postcode :");
		lblPostcodeLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		GridBagConstraints gbc_lblPostcodeLabel = new GridBagConstraints();
		gbc_lblPostcodeLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblPostcodeLabel.anchor = GridBagConstraints.EAST;
		gbc_lblPostcodeLabel.gridx = 4;
		gbc_lblPostcodeLabel.gridy = 5;
		panelContactDisplay.add(lblPostcodeLabel, gbc_lblPostcodeLabel);
		
		lblPostcode = new JLabel("Postcode");
		lblPostcode.setFont(new Font("Consolas", Font.PLAIN, 13));
		GridBagConstraints gbc_lblPostcode = new GridBagConstraints();
		gbc_lblPostcode.insets = new Insets(0, 0, 5, 5);
		gbc_lblPostcode.anchor = GridBagConstraints.WEST;
		gbc_lblPostcode.gridx = 6;
		gbc_lblPostcode.gridy = 5;
		panelContactDisplay.add(lblPostcode, gbc_lblPostcode);
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == btnClear)
		{
			clearFields();
		}
		
		if (e.getSource() == btnFindContact)
		{
			if (txtSearchField.getText() == null || txtSearchField.getText().equals(""))
			{
				JOptionPane.showMessageDialog(frameContactManager, "The field is empty. please provide a field before searching a contact", "Empty field", JOptionPane.ERROR_MESSAGE, null);
			}
			else
			{
				String fieldValue = txtSearchField.getText().trim();
				
				try
				{
					ContactRetrieverServiceStub.Contact c = cm.searchContact(fieldValue);

					setFields(c);
				}
				catch (RemoteException | ErrorFault error)
				{
					JOptionPane.showMessageDialog(frameContactManager, error.getMessage(), "Search", JOptionPane.ERROR_MESSAGE, null);
				}
			}
		}
		
		if (e.getSource() == btnInsertContact)
		{
			InsertContactDialog dialog = new InsertContactDialog(cm, this);
			dialog.setVisible(true);
		}
		
		
		if (e.getSource() == btnDeleteContact)
		{
			try {
				String phoneID = lblPhone.getText().trim();
				
				if (JOptionPane.showConfirmDialog(frameContactManager,
						"<html>Are you sure you want to delete the Contact?<br> This cannot be reversed.</html>",
						"", JOptionPane.YES_NO_OPTION,
						JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION)
				{
					cm.deleteContact(phoneID);
				}
				else
					return;
			}
			catch (ErrorFault | RemoteException error)
			{
				JOptionPane.showMessageDialog(frameContactManager, error.getMessage(), "Delete Error", JOptionPane.ERROR_MESSAGE, null);
			}
			
			clearFields();
			
			JOptionPane.showMessageDialog(frameContactManager, "The contact was deleted successfully!", "Success!", JOptionPane.INFORMATION_MESSAGE, null);
		}
		
		if (e.getSource() == btnModifyContact)
		{
			String fieldValue = txtSearchField.getText().trim();
			ContactRetrieverServiceStub.Contact c = null;

			try
			{
				c = cm.searchContact(fieldValue);
			}
			catch (RemoteException | ErrorFault error)
			{
				JOptionPane.showMessageDialog(frameContactManager, error.getMessage(), "Search", JOptionPane.ERROR_MESSAGE, null);
			}

			ModifyContactDialog dialog = new ModifyContactDialog(cm, this, c);
			dialog.setVisible(true);
		}
		
	}
	
	/**
	 * Sets the fields in the middle of the Frame to the values of the passed Contact.
	 * 
	 * @param c The Contact object to display.
	 */
	public void setFields(ContactRetrieverServiceStub.Contact c)
	{
		lblFirstName.setText(c.getFirstName());
		lblLastName.setText(c.getLastName());
		lblPhone.setText(c.getPhone());
		lblEmail.setText(c.getEmail());
		
		lblHouseNumber.setText(c.getAddress().getNumber());
		lblStreet.setText(c.getAddress().getStreet());
		lblCity.setText(c.getAddress().getCity());
		lblPostcode.setText(c.getAddress().getPostcode());
		
		txtSearchField.setText(c.getPhone());
		
		btnModifyContact.setEnabled(true);
		btnDeleteContact.setEnabled(true);
	}
	
	/**
	 * Clears the fields displaying the Contact's informations.
	 */
	private void clearFields()
	{
		lblFirstName.setText("");
		lblLastName.setText("");
		lblPhone.setText("");
		lblEmail.setText("");
		
		lblHouseNumber.setText("");
		lblStreet.setText("");
		lblCity.setText("");
		lblPostcode.setText("");
		
		txtSearchField.setText("");

		btnDeleteContact.setEnabled(false);
		btnModifyContact.setEnabled(false);
	}
}
