package appmanager;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import contactretriever.ContactRetrieverServiceStub;
import contactretriever.ContactRetrieverServiceStub.Contact;
import contactretriever.ErrorFault;
/**
 * @author 2634056
 */
public class ContactManager
{
	ContactRetrieverServiceStub stub;
	
	/**
	 * Constructor method for the ContactManager object.
	 */
	public ContactManager() 
	{
		try {
			stub = new ContactRetrieverServiceStub();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method bridges the communication between the UI and the web service.
	 * 
	 * @param c The updated contact object.
	 * @throws ErrorFault
	 * @throws RemoteException
	 */
	public void insertContact(ContactRetrieverServiceStub.Contact c) throws ErrorFault, RemoteException
	{
		ContactRetrieverServiceStub.InsertRequest request = new ContactRetrieverServiceStub.InsertRequest();
		// set the request's value to the passed contact object
		request.setInsertRequest(c);
	
		stub.insertContactOperation(request);
	}
	
	/**
	 * This method will make a request to the Service and returns a Contact object.
	 * 
	 * @param phoneID The phone number of the Contact we want to find.
	 * 
	 * @return The Contact object associated with the phone number.
	 * 
	 * @throws ErrorFault
	 * @throws RemoteException
	 */
	public Contact searchContact(String phoneID) throws ErrorFault, RemoteException
	{
		ContactRetrieverServiceStub.GetRequest request = new ContactRetrieverServiceStub.GetRequest();

		// set the request's value to passed phone number
		request.setGetRequest(phoneID);

		// call to the Service to find a Contact with the passed Request
		ContactRetrieverServiceStub.GetResponse response = stub.retrieveContactOperation(request);

		return response.getGetResponse();
	}

	/**
	 * This method sends a Contact object to the Service to modify it in the database.
	 * 
	 * @param c The updated Contact object.
	 * 
	 * @throws ErrorFault
	 * @throws RemoteException
	 */
	public void updateContact(Contact c) throws ErrorFault, RemoteException
	{
		ContactRetrieverServiceStub.ModifyRequest request = new ContactRetrieverServiceStub.ModifyRequest();

		// set the request's value to passed Contact object
		request.setModifyRequest(c);

		// call for the service to modify a contact in the database
		stub.modifyContactOperation(request);
	}
	
	/**
	 * This method sends a phone number to the Web Service to delete a contact in the database.
	 * 
	 * @param phoneID
	 * @throws ErrorFault
	 * @throws RemoteException
	 */
	public void deleteContact(String phoneID) throws ErrorFault, RemoteException
	{
		ContactRetrieverServiceStub.DeleteRequest request = new ContactRetrieverServiceStub.DeleteRequest();

		// set the request's value to passed phone number
		request.setDeleteRequest(phoneID);

		// call the web service to delete a contact in the database
		stub.deleteContactOperation(request);
	}
}
