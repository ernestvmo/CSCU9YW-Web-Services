package appmanager;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;
import javax.swing.JTextField;
import javax.swing.UIManager;
import java.awt.Insets;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import java.awt.Component;
import javax.swing.Box;

import contactretriever.ContactRetrieverServiceStub;
import contactretriever.ErrorFault;

public class InsertContactDialog extends JDialog implements ActionListener
{
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JTextField txtFirstName;
	private JTextField txtLastName;
	private JTextField txtPhone;
	private JTextField txtEmail;
	private JTextField txtHouseNum;
	private JTextField txtStreet;
	private JTextField txtCity;
	private JTextField txtPostcode;
	private JButton cancelButton;
	private JButton insertButton;
	
	private ContactManager cm;
	private UI mainUI;

	/**
	 * Create the dialog.
	 */
	public InsertContactDialog(ContactManager cm, UI parentUI)
	{
		setModal(true);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.cm = cm;
		initialize();
		mainUI = parentUI;
	}
	
	/**
	 * Initialise the dialog.
	 */
	private void initialize()
	{
		setResizable(false);
		setTitle("Insert Contact Dialog");
		setBounds(100, 100, 450, 418);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		GridBagLayout gbl_contentPanel = new GridBagLayout();
		gbl_contentPanel.columnWidths = new int[]{100, 0, 0};
		gbl_contentPanel.rowHeights = new int[]{0, 30, 30, 30, 30, 30, 30, 30, 30, 0, 0};
		gbl_contentPanel.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gbl_contentPanel.rowWeights = new double[]{1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPanel.setLayout(gbl_contentPanel);
		{
			JLabel lblNewLabel = new JLabel("First Name:");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 1;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			txtFirstName = new JTextField();
			GridBagConstraints gbc_txtFirstName = new GridBagConstraints();
			gbc_txtFirstName.insets = new Insets(0, 0, 5, 0);
			gbc_txtFirstName.fill = GridBagConstraints.BOTH;
			gbc_txtFirstName.gridx = 1;
			gbc_txtFirstName.gridy = 1;
			contentPanel.add(txtFirstName, gbc_txtFirstName);
			txtFirstName.setColumns(10);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("Last Name:");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
			gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
			gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_1.gridx = 0;
			gbc_lblNewLabel_1.gridy = 2;
			contentPanel.add(lblNewLabel_1, gbc_lblNewLabel_1);
		}
		{
			txtLastName = new JTextField();
			GridBagConstraints gbc_txtLastName = new GridBagConstraints();
			gbc_txtLastName.insets = new Insets(0, 0, 5, 0);
			gbc_txtLastName.fill = GridBagConstraints.BOTH;
			gbc_txtLastName.gridx = 1;
			gbc_txtLastName.gridy = 2;
			contentPanel.add(txtLastName, gbc_txtLastName);
			txtLastName.setColumns(10);
		}
		{
			JLabel lblNewLabel_2 = new JLabel("Phone");
			lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
			gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
			gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_2.gridx = 0;
			gbc_lblNewLabel_2.gridy = 3;
			contentPanel.add(lblNewLabel_2, gbc_lblNewLabel_2);
		}
		{
			txtPhone = new JTextField();
			GridBagConstraints gbc_txtPhone = new GridBagConstraints();
			gbc_txtPhone.insets = new Insets(0, 0, 5, 0);
			gbc_txtPhone.fill = GridBagConstraints.BOTH;
			gbc_txtPhone.gridx = 1;
			gbc_txtPhone.gridy = 3;
			contentPanel.add(txtPhone, gbc_txtPhone);
			txtPhone.setColumns(10);
		}
		{
			JLabel lblNewLabel_3 = new JLabel("Email:");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
			gbc_lblNewLabel_3.anchor = GridBagConstraints.EAST;
			gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_3.gridx = 0;
			gbc_lblNewLabel_3.gridy = 4;
			contentPanel.add(lblNewLabel_3, gbc_lblNewLabel_3);
		}
		{
			txtEmail = new JTextField();
			GridBagConstraints gbc_txtEmail = new GridBagConstraints();
			gbc_txtEmail.insets = new Insets(0, 0, 5, 0);
			gbc_txtEmail.fill = GridBagConstraints.BOTH;
			gbc_txtEmail.gridx = 1;
			gbc_txtEmail.gridy = 4;
			contentPanel.add(txtEmail, gbc_txtEmail);
			txtEmail.setColumns(10);
		}
		{
			JLabel lblNewLabel_5 = new JLabel("House Nº:");
			lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
			gbc_lblNewLabel_5.anchor = GridBagConstraints.EAST;
			gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_5.gridx = 0;
			gbc_lblNewLabel_5.gridy = 5;
			contentPanel.add(lblNewLabel_5, gbc_lblNewLabel_5);
		}
		{
			txtHouseNum = new JTextField();
			GridBagConstraints gbc_txtHouseNum = new GridBagConstraints();
			gbc_txtHouseNum.insets = new Insets(0, 0, 5, 0);
			gbc_txtHouseNum.fill = GridBagConstraints.BOTH;
			gbc_txtHouseNum.gridx = 1;
			gbc_txtHouseNum.gridy = 5;
			contentPanel.add(txtHouseNum, gbc_txtHouseNum);
			txtHouseNum.setColumns(10);
		}
		{
			JLabel lblStreet = new JLabel("Street:");
			lblStreet.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblStreet = new GridBagConstraints();
			gbc_lblStreet.anchor = GridBagConstraints.EAST;
			gbc_lblStreet.insets = new Insets(0, 0, 5, 5);
			gbc_lblStreet.gridx = 0;
			gbc_lblStreet.gridy = 6;
			contentPanel.add(lblStreet, gbc_lblStreet);
		}
		{
			txtStreet = new JTextField();
			GridBagConstraints gbc_txtStreet = new GridBagConstraints();
			gbc_txtStreet.insets = new Insets(0, 0, 5, 0);
			gbc_txtStreet.fill = GridBagConstraints.BOTH;
			gbc_txtStreet.gridx = 1;
			gbc_txtStreet.gridy = 6;
			contentPanel.add(txtStreet, gbc_txtStreet);
			txtStreet.setColumns(10);
		}
		{
			JLabel lblCity = new JLabel("City:");
			lblCity.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblCity = new GridBagConstraints();
			gbc_lblCity.anchor = GridBagConstraints.EAST;
			gbc_lblCity.insets = new Insets(0, 0, 5, 5);
			gbc_lblCity.gridx = 0;
			gbc_lblCity.gridy = 7;
			contentPanel.add(lblCity, gbc_lblCity);
		}
		{
			txtCity = new JTextField();
			GridBagConstraints gbc_txtCity = new GridBagConstraints();
			gbc_txtCity.insets = new Insets(0, 0, 5, 0);
			gbc_txtCity.fill = GridBagConstraints.BOTH;
			gbc_txtCity.gridx = 1;
			gbc_txtCity.gridy = 7;
			contentPanel.add(txtCity, gbc_txtCity);
			txtCity.setColumns(10);
		}
		{
			JLabel lblPostcode = new JLabel("Postcode:");
			lblPostcode.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblPostcode = new GridBagConstraints();
			gbc_lblPostcode.anchor = GridBagConstraints.EAST;
			gbc_lblPostcode.insets = new Insets(0, 0, 5, 5);
			gbc_lblPostcode.gridx = 0;
			gbc_lblPostcode.gridy = 8;
			contentPanel.add(lblPostcode, gbc_lblPostcode);
		}
		{
			txtPostcode = new JTextField();
			GridBagConstraints gbc_txtPostcode = new GridBagConstraints();
			gbc_txtPostcode.insets = new Insets(0, 0, 5, 0);
			gbc_txtPostcode.fill = GridBagConstraints.BOTH;
			gbc_txtPostcode.gridx = 1;
			gbc_txtPostcode.gridy = 8;
			contentPanel.add(txtPostcode, gbc_txtPostcode);
			txtPostcode.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				insertButton = new JButton("Insert");
				insertButton.addActionListener(this);
				insertButton.setPreferredSize(new Dimension(80, 30));
				buttonPane.add(insertButton);
				getRootPane().setDefaultButton(insertButton);
			}
			{
				cancelButton = new JButton("Cancel");
				cancelButton.setPreferredSize(new Dimension(80, 30));
				cancelButton.addActionListener(this);
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		{
			Component horizontalStrut = Box.createHorizontalStrut(20);
			getContentPane().add(horizontalStrut, BorderLayout.EAST);
		}
		{
			Component horizontalStrut = Box.createHorizontalStrut(20);
			getContentPane().add(horizontalStrut, BorderLayout.WEST);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == cancelButton)
		{
			 this.dispose();
		}
		
		if (e.getSource() == insertButton)
		{
			if (sanitizeTextBoxModify(txtFirstName, txtLastName, txtPhone, txtEmail, txtHouseNum, txtStreet, txtCity, txtPostcode))
			{
				ContactRetrieverServiceStub.Contact c = new ContactRetrieverServiceStub.Contact();
				ContactRetrieverServiceStub.Address a = new ContactRetrieverServiceStub.Address();
				
				a.setStreet(txtStreet.getText());
				a.setNumber(txtHouseNum.getText());
				a.setCity(txtCity.getText());
				a.setPostcode(txtPostcode.getText());
				
				c.setFirstName(txtFirstName.getText());
				c.setLastName(txtLastName.getText());
				c.setPhone(txtPhone.getText());
				c.setEmail(txtEmail.getText());
				c.setAddress(a);
				
				try {
					cm.insertContact(c);
				}
				catch (ErrorFault | RemoteException error) {
					JOptionPane.showMessageDialog(this, error.getMessage(), "Insert Error", JOptionPane.ERROR_MESSAGE, null);
					return;
				}
				
				JOptionPane.showMessageDialog(this, "Contact Successfully inserted!", "Success!", JOptionPane.INFORMATION_MESSAGE, null);
				
				mainUI.setFields(c);
				this.dispose();
			}
			else
				JOptionPane.showMessageDialog(this, "Some fields are incorrect, please try again.", "Input Error", JOptionPane.ERROR_MESSAGE, null);
		}
	}

	/**
	 * Checks the inputs in the passed fields to validate the inputs.
	 * 
	 * @param txtFields The JTextField objects to validate.
	 * 
	 * @return {@code false} if any field does not have good value, {@code true} otherwise.
	 */
	private boolean sanitizeTextBoxModify(JTextField... txtFields)
	{
		boolean valid = true;

		for (int i = 0; i < txtFields.length; i++)
		{
			if (txtFields[i].getText() == null || txtFields[i].getText().equals(""))
			{
				txtFields[i].setBorder(new LineBorder(Color.RED));
				valid = false;
			} else
				txtFields[i].setBorder(UIManager.getLookAndFeel().getDefaults().getBorder("TextField.border"));
		}

		return valid;
	}

}


























