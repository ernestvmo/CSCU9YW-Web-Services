package appmanager;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import contactretriever.ContactRetrieverServiceStub;
import contactretriever.ErrorFault;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridBagConstraints;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.awt.event.ActionEvent;

public class ModifyContactDialog extends JDialog implements ActionListener
{

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JTextField txtNewFirstName;
	private JTextField txtNewLastName;
	private JTextField txtNewPhone;
	private JTextField txtNewEmail;
	private JTextField txtNewHouseNum;
	private JTextField txtNewStreet;
	private JTextField txtNewCity;
	private JTextField txtNewPostcode;
	private JButton modifyButton;
	private JButton cancelButton;
	
	private ContactManager cm;
	private UI mainUI;
	private ContactRetrieverServiceStub.Contact oldContact;

	/**
	 * Create the dialog.
	 */
	public ModifyContactDialog(ContactManager cm, UI ui, ContactRetrieverServiceStub.Contact oldContact)
	{
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setModal(true);
		this.cm = cm;
		this.mainUI = ui;
		this.oldContact = oldContact;
		initialize();
	}
	
	/**
	 * Initialise the dialog.
	 */
	private void initialize()
	{
		setBounds(100, 100, 670, 438);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		GridBagLayout gbl_contentPanel = new GridBagLayout();
		gbl_contentPanel.columnWidths = new int[]{0, 0, 30, 150, 30, 250, 0, 0};
		gbl_contentPanel.rowHeights = new int[]{0, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0, 0};
		gbl_contentPanel.columnWeights = new double[]{1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_contentPanel.rowWeights = new double[]{1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPanel.setLayout(gbl_contentPanel);
		{
			JLabel lblNewLabel = new JLabel("Old");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 3;
			gbc_lblNewLabel.gridy = 1;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JLabel lblNew = new JLabel("New");
			lblNew.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblNew = new GridBagConstraints();
			gbc_lblNew.insets = new Insets(0, 0, 5, 5);
			gbc_lblNew.gridx = 5;
			gbc_lblNew.gridy = 1;
			contentPanel.add(lblNew, gbc_lblNew);
		}
		{
			JLabel lblFirstNameLabel = new JLabel("First Name :");
			lblFirstNameLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblFirstNameLabel = new GridBagConstraints();
			gbc_lblFirstNameLabel.anchor = GridBagConstraints.EAST;
			gbc_lblFirstNameLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblFirstNameLabel.gridx = 1;
			gbc_lblFirstNameLabel.gridy = 2;
			contentPanel.add(lblFirstNameLabel, gbc_lblFirstNameLabel);
		}
		{
			JLabel lblFirstNameOld = new JLabel(oldContact.getFirstName());
			lblFirstNameOld.setFont(new Font("Consolas", Font.PLAIN, 13));
			GridBagConstraints gbc_lblFirstNameOld = new GridBagConstraints();
			gbc_lblFirstNameOld.anchor = GridBagConstraints.WEST;
			gbc_lblFirstNameOld.insets = new Insets(0, 0, 5, 5);
			gbc_lblFirstNameOld.gridx = 3;
			gbc_lblFirstNameOld.gridy = 2;
			contentPanel.add(lblFirstNameOld, gbc_lblFirstNameOld);
		}
		{
			txtNewFirstName = new JTextField();
			GridBagConstraints gbc_txtNewFirstName = new GridBagConstraints();
			gbc_txtNewFirstName.insets = new Insets(0, 0, 5, 5);
			gbc_txtNewFirstName.fill = GridBagConstraints.BOTH;
			gbc_txtNewFirstName.gridx = 5;
			gbc_txtNewFirstName.gridy = 2;
			contentPanel.add(txtNewFirstName, gbc_txtNewFirstName);
			txtNewFirstName.setColumns(10);
		}
		{
			JLabel lblLastNameLabel = new JLabel("Last Name :");
			lblLastNameLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblLastNameLabel = new GridBagConstraints();
			gbc_lblLastNameLabel.anchor = GridBagConstraints.EAST;
			gbc_lblLastNameLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblLastNameLabel.gridx = 1;
			gbc_lblLastNameLabel.gridy = 3;
			contentPanel.add(lblLastNameLabel, gbc_lblLastNameLabel);
		}
		{
			JLabel lblLastNameOld = new JLabel(oldContact.getLastName());
			lblLastNameOld.setFont(new Font("Consolas", Font.PLAIN, 13));
			GridBagConstraints gbc_lblLastNameOld = new GridBagConstraints();
			gbc_lblLastNameOld.anchor = GridBagConstraints.WEST;
			gbc_lblLastNameOld.insets = new Insets(0, 0, 5, 5);
			gbc_lblLastNameOld.gridx = 3;
			gbc_lblLastNameOld.gridy = 3;
			contentPanel.add(lblLastNameOld, gbc_lblLastNameOld);
		}
		{
			txtNewLastName = new JTextField();
			GridBagConstraints gbc_txtNewLastName = new GridBagConstraints();
			gbc_txtNewLastName.insets = new Insets(0, 0, 5, 5);
			gbc_txtNewLastName.fill = GridBagConstraints.BOTH;
			gbc_txtNewLastName.gridx = 5;
			gbc_txtNewLastName.gridy = 3;
			contentPanel.add(txtNewLastName, gbc_txtNewLastName);
			txtNewLastName.setColumns(10);
		}
		{
			JLabel lblPhoneLabel = new JLabel("Phone :");
			lblPhoneLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblPhoneLabel = new GridBagConstraints();
			gbc_lblPhoneLabel.anchor = GridBagConstraints.EAST;
			gbc_lblPhoneLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblPhoneLabel.gridx = 1;
			gbc_lblPhoneLabel.gridy = 4;
			contentPanel.add(lblPhoneLabel, gbc_lblPhoneLabel);
		}
		{
			JLabel lblPhoneOld = new JLabel(oldContact.getPhone());
			lblPhoneOld.setFont(new Font("Consolas", Font.PLAIN, 13));
			GridBagConstraints gbc_lblPhoneOld = new GridBagConstraints();
			gbc_lblPhoneOld.anchor = GridBagConstraints.WEST;
			gbc_lblPhoneOld.insets = new Insets(0, 0, 5, 5);
			gbc_lblPhoneOld.gridx = 3;
			gbc_lblPhoneOld.gridy = 4;
			contentPanel.add(lblPhoneOld, gbc_lblPhoneOld);
		}
		{
			txtNewPhone = new JTextField();
			txtNewPhone.setToolTipText("<html>This field cannot be changed as <br>it is used as identifier in the database.</html>");
			txtNewPhone.setEditable(false);
			GridBagConstraints gbc_txtNewPhone = new GridBagConstraints();
			gbc_txtNewPhone.insets = new Insets(0, 0, 5, 5);
			gbc_txtNewPhone.fill = GridBagConstraints.BOTH;
			gbc_txtNewPhone.gridx = 5;
			gbc_txtNewPhone.gridy = 4;
			contentPanel.add(txtNewPhone, gbc_txtNewPhone);
			txtNewPhone.setColumns(10);
		}
		{
			JLabel lblEmailLabel = new JLabel("Email :");
			lblEmailLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblEmailLabel = new GridBagConstraints();
			gbc_lblEmailLabel.anchor = GridBagConstraints.EAST;
			gbc_lblEmailLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblEmailLabel.gridx = 1;
			gbc_lblEmailLabel.gridy = 5;
			contentPanel.add(lblEmailLabel, gbc_lblEmailLabel);
		}
		{
			JLabel lblEmailOld = new JLabel(oldContact.getEmail());
			lblEmailOld.setFont(new Font("Consolas", Font.PLAIN, 13));
			GridBagConstraints gbc_lblEmailOld = new GridBagConstraints();
			gbc_lblEmailOld.anchor = GridBagConstraints.WEST;
			gbc_lblEmailOld.insets = new Insets(0, 0, 5, 5);
			gbc_lblEmailOld.gridx = 3;
			gbc_lblEmailOld.gridy = 5;
			contentPanel.add(lblEmailOld, gbc_lblEmailOld);
		}
		{
			txtNewEmail = new JTextField();
			GridBagConstraints gbc_txtNewEmail = new GridBagConstraints();
			gbc_txtNewEmail.insets = new Insets(0, 0, 5, 5);
			gbc_txtNewEmail.fill = GridBagConstraints.BOTH;
			gbc_txtNewEmail.gridx = 5;
			gbc_txtNewEmail.gridy = 5;
			contentPanel.add(txtNewEmail, gbc_txtNewEmail);
			txtNewEmail.setColumns(10);
		}
		{
			JLabel lblHouseNumLabel = new JLabel("Nº :");
			lblHouseNumLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblHouseNumLabel = new GridBagConstraints();
			gbc_lblHouseNumLabel.anchor = GridBagConstraints.EAST;
			gbc_lblHouseNumLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblHouseNumLabel.gridx = 1;
			gbc_lblHouseNumLabel.gridy = 7;
			contentPanel.add(lblHouseNumLabel, gbc_lblHouseNumLabel);
		}
		{
			JLabel lblHouseNumOld = new JLabel(oldContact.getAddress().getNumber());
			lblHouseNumOld.setFont(new Font("Consolas", Font.PLAIN, 13));
			GridBagConstraints gbc_lblHouseNumOld = new GridBagConstraints();
			gbc_lblHouseNumOld.anchor = GridBagConstraints.WEST;
			gbc_lblHouseNumOld.insets = new Insets(0, 0, 5, 5);
			gbc_lblHouseNumOld.gridx = 3;
			gbc_lblHouseNumOld.gridy = 7;
			contentPanel.add(lblHouseNumOld, gbc_lblHouseNumOld);
		}
		{
			txtNewHouseNum = new JTextField();
			GridBagConstraints gbc_txtNewHouseNum = new GridBagConstraints();
			gbc_txtNewHouseNum.insets = new Insets(0, 0, 5, 5);
			gbc_txtNewHouseNum.fill = GridBagConstraints.BOTH;
			gbc_txtNewHouseNum.gridx = 5;
			gbc_txtNewHouseNum.gridy = 7;
			contentPanel.add(txtNewHouseNum, gbc_txtNewHouseNum);
			txtNewHouseNum.setColumns(10);
		}
		{
			JLabel lblStreetLabel = new JLabel("Street :");
			lblStreetLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblStreetLabel = new GridBagConstraints();
			gbc_lblStreetLabel.anchor = GridBagConstraints.EAST;
			gbc_lblStreetLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblStreetLabel.gridx = 1;
			gbc_lblStreetLabel.gridy = 8;
			contentPanel.add(lblStreetLabel, gbc_lblStreetLabel);
		}
		{
			JLabel lblStreetOld = new JLabel(oldContact.getAddress().getStreet());
			lblStreetOld.setFont(new Font("Consolas", Font.PLAIN, 13));
			GridBagConstraints gbc_lblStreetOld = new GridBagConstraints();
			gbc_lblStreetOld.anchor = GridBagConstraints.WEST;
			gbc_lblStreetOld.insets = new Insets(0, 0, 5, 5);
			gbc_lblStreetOld.gridx = 3;
			gbc_lblStreetOld.gridy = 8;
			contentPanel.add(lblStreetOld, gbc_lblStreetOld);
		}
		{
			txtNewStreet = new JTextField();
			GridBagConstraints gbc_txtNewStreet = new GridBagConstraints();
			gbc_txtNewStreet.insets = new Insets(0, 0, 5, 5);
			gbc_txtNewStreet.fill = GridBagConstraints.BOTH;
			gbc_txtNewStreet.gridx = 5;
			gbc_txtNewStreet.gridy = 8;
			contentPanel.add(txtNewStreet, gbc_txtNewStreet);
			txtNewStreet.setColumns(10);
		}
		{
			JLabel lblCityLabel = new JLabel("City :");
			lblCityLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblCityLabel = new GridBagConstraints();
			gbc_lblCityLabel.anchor = GridBagConstraints.EAST;
			gbc_lblCityLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblCityLabel.gridx = 1;
			gbc_lblCityLabel.gridy = 9;
			contentPanel.add(lblCityLabel, gbc_lblCityLabel);
		}
		{
			JLabel lblCityOld = new JLabel(oldContact.getAddress().getCity());
			lblCityOld.setFont(new Font("Consolas", Font.PLAIN, 13));
			GridBagConstraints gbc_lblCityOld = new GridBagConstraints();
			gbc_lblCityOld.anchor = GridBagConstraints.WEST;
			gbc_lblCityOld.insets = new Insets(0, 0, 5, 5);
			gbc_lblCityOld.gridx = 3;
			gbc_lblCityOld.gridy = 9;
			contentPanel.add(lblCityOld, gbc_lblCityOld);
		}
		{
			txtNewCity = new JTextField();
			GridBagConstraints gbc_txtNewCity = new GridBagConstraints();
			gbc_txtNewCity.insets = new Insets(0, 0, 5, 5);
			gbc_txtNewCity.fill = GridBagConstraints.BOTH;
			gbc_txtNewCity.gridx = 5;
			gbc_txtNewCity.gridy = 9;
			contentPanel.add(txtNewCity, gbc_txtNewCity);
			txtNewCity.setColumns(10);
		}
		{
			JLabel lblPostcodeLabel = new JLabel("Postcode :");
			lblPostcodeLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
			GridBagConstraints gbc_lblPostcodeLabel = new GridBagConstraints();
			gbc_lblPostcodeLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblPostcodeLabel.anchor = GridBagConstraints.EAST;
			gbc_lblPostcodeLabel.gridx = 1;
			gbc_lblPostcodeLabel.gridy = 10;
			contentPanel.add(lblPostcodeLabel, gbc_lblPostcodeLabel);
		}
		{
			JLabel lblPostcodeOld = new JLabel(oldContact.getAddress().getPostcode());
			lblPostcodeOld.setFont(new Font("Consolas", Font.PLAIN, 13));
			GridBagConstraints gbc_lblPostcodeOld = new GridBagConstraints();
			gbc_lblPostcodeOld.anchor = GridBagConstraints.WEST;
			gbc_lblPostcodeOld.insets = new Insets(0, 0, 5, 5);
			gbc_lblPostcodeOld.gridx = 3;
			gbc_lblPostcodeOld.gridy = 10;
			contentPanel.add(lblPostcodeOld, gbc_lblPostcodeOld);
		}
		{
			txtNewPostcode = new JTextField();
			GridBagConstraints gbc_txtNewPostcode = new GridBagConstraints();
			gbc_txtNewPostcode.insets = new Insets(0, 0, 5, 5);
			gbc_txtNewPostcode.fill = GridBagConstraints.BOTH;
			gbc_txtNewPostcode.gridx = 5;
			gbc_txtNewPostcode.gridy = 10;
			contentPanel.add(txtNewPostcode, gbc_txtNewPostcode);
			txtNewPostcode.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				modifyButton = new JButton("Modify");
				modifyButton.addActionListener(this);
				modifyButton.setPreferredSize(new Dimension(80, 35));
				modifyButton.setActionCommand("OK");
				buttonPane.add(modifyButton);
				getRootPane().setDefaultButton(modifyButton);
			}
			{
				cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(this);
				cancelButton.setPreferredSize(new Dimension(80, 35));
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == cancelButton)
		{
			this.dispose();
		}
		
		if (e.getSource() == modifyButton)
		{
//			if (sanitizeTextBoxModify(txtNewFirstName, txtNewLastName,
//					txtNewEmail, txtNewHouseNum, txtNewStreet,
//					txtNewCity, txtNewPostcode))
			{
				ContactRetrieverServiceStub.Address a = new ContactRetrieverServiceStub.Address();
				ContactRetrieverServiceStub.Contact c = new ContactRetrieverServiceStub.Contact();

				String newNum = (txtNewHouseNum.getText().trim() == null || txtNewHouseNum.getText().trim().equals("")) ? oldContact.getAddress().getNumber() : txtNewHouseNum.getText().trim();
				a.setNumber(newNum);
				String newStreet = (txtNewStreet.getText().trim() == null || txtNewStreet.getText().trim().equals("")) ? oldContact.getAddress().getStreet() : txtNewStreet.getText().trim();
				a.setStreet(newStreet);
				String newCity = (txtNewCity.getText().trim() == null || txtNewCity.getText().trim().equals("")) ? oldContact.getAddress().getCity() : txtNewCity.getText().trim();
				a.setCity(newCity);
				String newPostcode = (txtNewPostcode.getText().trim() == null || txtNewPostcode.getText().trim().equals("")) ? oldContact.getAddress().getPostcode() : txtNewPostcode.getText().trim();
				a.setPostcode(newPostcode);

				String newFName = (txtNewFirstName.getText().trim() == null || txtNewFirstName.getText().trim().equals("")) ? oldContact.getFirstName() : txtNewFirstName.getText().trim();
				c.setFirstName(newFName);
				String newLName = (txtNewLastName.getText().trim() == null || txtNewLastName.getText().trim().equals("")) ? oldContact.getLastName() : txtNewLastName.getText().trim();
				c.setLastName(newLName);
				String newPhone = (txtNewPhone.getText().trim() == null || txtNewPhone.getText().trim().equals("")) ? oldContact.getPhone() : txtNewPhone.getText().trim();
				c.setPhone(newPhone);
				String newEmail = (txtNewEmail.getText().trim() == null || txtNewEmail.getText().trim().equals("")) ? oldContact.getEmail() : txtNewEmail.getText().trim();
				c.setEmail(newEmail);
				c.setAddress(a);

				try
				{
					if (JOptionPane.showConfirmDialog(this,
							"<html>The fields left blank remain unedited, <br>are you sure you want to modify the Contact?</html>",
							"", JOptionPane.YES_NO_OPTION,
							JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION)
						cm.updateContact(c);
					else
						return;
				}
				catch (ErrorFault | RemoteException error)
				{
					JOptionPane.showMessageDialog(this, error.getMessage(), "Update Failed", JOptionPane.ERROR_MESSAGE, null);
				}

				JOptionPane.showMessageDialog(this, "Contact successfully modified!", "Success!", JOptionPane.INFORMATION_MESSAGE, null);
				mainUI.setFields(c);
				this.dispose();
			} 
//			else
//			{
//				JOptionPane.showMessageDialog(this, "Some fields are empty or incorrect, please check and try again after fixing it.", "Input error", JOptionPane.ERROR_MESSAGE);
//			}
		}
	}

//	/**
//	 * Checks the inputs in the passed fields to validate the inputs.
//	 * 
//	 * @param txtFields The JTextFields to validate.
//	 * 
//	 * @return {@code false} if any field does not have good value, {@code true} otherwise.
//	 */
//	private boolean sanitizeTextBoxModify(JTextField... txtFields)
//	{
//		boolean valid = true;
//
//		for (int i = 0; i < txtFields.length; i++)
//		{
//			if (txtFields[i].getText() == null || txtFields[i].getText().equals(""))
//			{
//				txtFields[i].setBorder(new LineBorder(Color.RED));
//				valid = false;
//			} else
//				txtFields[i].setBorder(new LineBorder(Color.BLACK));// TODO default
//		}
//
//		return valid;
//	}

}
